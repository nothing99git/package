def hi ():
	return "hi"