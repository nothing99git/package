from setuptools import setup, find_packages

setup(
    name='my_package',  # Replace with your desired package name
    version='0.1.0',
    author='Your Name',
    description='A short description of your package',
    packages=find_packages(),  # Automatically finds all packages
    install_requires=[],  # Add required packages here
    classifiers=[
        'Programming Language :: Python :: 3',
    ],
    python_requires='>=3.6',
)
